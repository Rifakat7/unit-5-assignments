import "./styles.css";
import { Counter } from "./counter.js";

export default function App() {
  return (
    
    <Counter />
  );
}
